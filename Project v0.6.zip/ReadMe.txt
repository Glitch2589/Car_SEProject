version 0.6
by Quyet
- hoàn thiện signup, login, logout
=========
version 0.5
by Quyet
- update kết nối với firebase
=========
version 0.4
by Quyet
- fix hầu hết bugs
- group storyboards và viewcontroller gọn hơn
- Tinh chỉnh 1 chút frontend phần login
=========
version 0.3.2 -> 0.3.3
by Quyet
- clean code
+ fix minor bug (sai tên?)
=========
version 0.3.1
by Quyet
- Chia nhỏ từng phần ra để có thể làm chung trong 1 project - Để sửa layout 
=========
version 0.3
by Quyet
- Cập nhật Navigation Bars (ko biết cần ko nhưng thêm vô đã)
==========
version 0.2
Make by Quyet
- Cập nhật Tab Bar Controller của Home (Nơi lựa xe), Search (Tìm Kiếm), Profile (Thông tin cá nhân)
- Cập nhật tạm thời Login as Tester
===========
version 0.1
Make by Quyet
- Cập Nhật UI của Log In Và Sign Up
- Update chức năng chuyển trang qua lại giữa 2 cái UI này
