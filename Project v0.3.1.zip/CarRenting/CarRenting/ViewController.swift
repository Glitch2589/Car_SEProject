//
//  ViewController.swift
//  CarRenting
//
//  Created by Hoàng Quyết on 10/6/20.
//  Copyright © 2020 HaZuWy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

