//
//  SearchViewController.swift
//  CarRenting
//
//  Created by Hoàng Quyết on 12/1/20.
//  Copyright © 2020 HaZuWy. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

}
